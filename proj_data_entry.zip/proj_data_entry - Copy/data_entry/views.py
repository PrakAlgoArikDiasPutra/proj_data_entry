from django.shortcuts import render, get_object_or_404
from .forms import AddressForm, PenggunaForm, ContentForm
from .models import Pengguna
from django.http import JsonResponse
from .models import Content
from django.shortcuts import redirect

from django.shortcuts import render, get_object_or_404
from .forms import AddressForm, PenggunaForm, ContentForm
from .models import Pengguna
from django.http import JsonResponse
from .models import Content
from .forms import PhotoForm


# Create your views here.
def set_data_entry(request):
    form = AddressForm()
    context = {
        'form': form,
    }
    return render(request, 'data_entry/input_data.html', context)

def set_content(request):
    form = ContentForm(None)
    pengguna = None
    email = None

    if request.session.get('email', None):
        email = request.session.get('email')
        pengguna = Pengguna.objects.get(email=email)
        initial_data = {'author': pengguna}
        form = ContentForm(initial=initial_data)

    if request.method == "POST":
        form = ContentForm(request.POST)
        if form.is_valid():
            form.save()

    # Ambil semua konten untuk ditampilkan di tabel
    daftar_konten = Content.objects.select_related('author').order_by('-created_at')

    context = {
        'form': form,
        'email': email,
        'pengguna': pengguna,
        'daftar_konten': daftar_konten,  # ini penting untuk tabel
    }

    return render(request, 'data_entry/create_content.html', context)



# Cari pengguna berdasarkan nama state
def search_pengguna_by_state(request):
    query = request.GET.get('state')
    results = []

    if query:
        results = Pengguna.objects.filter(state__icontains=query)

    context = {
        'query': query,
        'results': results
    }
    return render(request, 'data_entry/search_pengguna.html',context)


def set_pengguna(request):
    list_pengguna = Pengguna.objects.all().order_by('-id')
    context = None
    form = PenggunaForm(None)
    email_p = None
    if request.method == "POST":
        form = PenggunaForm(request.POST)
        if form.is_valid():
            # simpan id pengguna pada saat user klik menu sign in
            email = form.cleaned_data['email']
            request.session['email'] = email
            request.session.modified = True
            form.save()
            list_pengguna = Pengguna.objects.all().order_by('-id')
            email_p = request.session['email']
            context = {
                'form': form,
                'list_pengguna': list_pengguna,
                'email_p': email_p,
            }
            return render(request, 'data_entry/input_data_1.html', context)
            
    else:
        context = {
            'form': form,
            'list_pengguna': list_pengguna,
        }
        return render(request, 'data_entry/input_data_1.html', context)
        

def view_pengguna(request):
    pass

def view_pengguna(request, id):
    try:
        pengguna = get_object_or_404 (Pengguna, pk=id)
        print(pengguna)
        return render(request, 'data_entry/pengguna_detail.html', {'pengguna': pengguna})
    except Pengguna.DoesNotExist:
        return JsonResponse({'error': 'User not found'}, status=404)

def get_pengguna_detail_api(request, user_id):
    try:
        pengguna = Pengguna.objects.get(pk=user_id)
        data = {
            'email': pengguna.email,
            'address_1': pengguna.address_1,
            'address_2': pengguna.address_2,
            'city': pengguna.city,
            'state': pengguna.state,
            'zip_code': pengguna.zip_code,
            'tanggal_join': pengguna.tanggal_join.strftime('%Y-%m-%d')  # Format date as string
        }
        return JsonResponse(data)
    except Pengguna.DoesNotExist:
        return JsonResponse({'error': 'User not found'},status=404)

def update_pengguna(request, id):
    pengguna = get_object_or_404(Pengguna, pk=id)
    form = PenggunaForm(instance=pengguna)

    if request.method == 'POST':
        form = PenggunaForm(request.POST, instance=pengguna)
        if form.is_valid():
            form.save()
            return redirect('data_entry:set_pengguna')  

    context = {
        'form': form,
        'pengguna': pengguna,
        'edit_mode': True  
    }
    return render(request, 'data_entry/input_data_1.html', context)

def delete_pengguna(request, id):
    pengguna = get_object_or_404(Pengguna, id=id)
    pengguna.delete()
    return redirect('data_entry:set_pengguna')  # Ganti dengan nama halaman setelah hapus

def set_content(request):
    form = ContentForm(None)
    pengguna = None
    email = None

    if request.session.get('email', None):
        email = request.session.get('email')
        try:
            pengguna = Pengguna.objects.get(email=email)
            initial_data = {'author': pengguna}
            form = ContentForm(initial=initial_data)
        except Pengguna.DoesNotExist:
            pengguna = None  # biar aman, pengguna jadi None

    if request.method == "POST":
        form = ContentForm(request.POST)
        if form.is_valid():
            form.save()

    daftar_konten = Content.objects.select_related('author').order_by('-created_at')

    context = {
        'form': form,
        'email': email,
        'pengguna': pengguna,
        'daftar_konten': daftar_konten,
    }

    return render(request, 'data_entry/create_content.html', context)

def upload_photo(request):
    if request.method == 'POST':
        form = PhotoForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('data_entry:upload_success')
    else:
        form = PhotoForm()
        return render(request, 'data_entry/upload_photo.html', {'form': form})

def upload_success(request):
    return render(request, 'data_entry/upload_success.html')

from .models import Photo
def photo_list(request):
    photos = Photo.objects.all()
    context = {'photos': photos}
    return render(request, 'data_entry/photo_list.html', {'photos': photos})
