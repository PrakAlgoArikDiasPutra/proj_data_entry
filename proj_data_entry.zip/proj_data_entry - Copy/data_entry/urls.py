from django.urls import path
from . import views

urlpatterns = [
    path('', views.set_pengguna, name='set_pengguna'),  # Home page, set_pengguna
    path('data_entry/', views.set_data_entry, name='set_data_entry'),  # Data entry page
    path('pengguna/', views.set_pengguna, name='set_pengguna'),  # Pengguna listing page
    path('pengguna/view/<int:id>/', views.view_pengguna, name='view_pengguna'),  # View specific pengguna
    path('api/pengguna/<int:user_id>/', views.get_pengguna_detail_api, name='get_pengguna_detail_api'),  # API to fetch pengguna details
    path('content/', views.set_content, name='set_content'),  # Content page
    path('pengguna/listpenggunabystate', views.search_pengguna_by_state, name='search_pengguna_by_state'),  # Search by state
    path('pengguna/<int:id>/view', views.view_pengguna, name='viewdata'),  # Duplicate of 'view_pengguna' with different URL pattern
    path('pengguna/<int:id>/update', views.update_pengguna, name='updatedata'),  # Update pengguna
    path('pengguna/<int:id>/delete', views.delete_pengguna, name='deletedata'),  # Delete pengguna
    path('upload', views.upload_photo, name='upload_photo'),  # Upload photo page
    path('success/', views.upload_success, name='upload_success'),  # Success page after upload
    path('photos/', views.photo_list, name='photo_list'),  # List of photos uploaded
]
