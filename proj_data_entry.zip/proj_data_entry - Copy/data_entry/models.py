from django.db import models
from django.contrib.auth.models import User
from django import forms
from datetime import date

# Create your models here.
class Pengguna(models.Model):
    email = models.EmailField(unique=True)  # Menambahkan unique=True agar tidak ada duplikasi email
    password = models.CharField(max_length=100)
    address_1 = models.CharField(max_length=255)  # Menggunakan CharField dengan batasan panjang
    address_2 = models.CharField(max_length=255, null=True, blank=True)  # Sama seperti address_1
    city = models.CharField(max_length=50, help_text='Enter your city')
    state = models.CharField(max_length=50, verbose_name="State")  # Menggunakan CharField dengan batasan panjang
    zip_code = models.CharField(max_length=10)  # Memperbesar max_length agar fleksibel
    tanggal_join = models.DateField(default=date.today)  # Menggunakan default agar bisa diedit nanti

    def __str__(self):
        return self.email  # Menampilkan email sebagai representasi objek
    
class Content(models.Model):
    author = models.ForeignKey(Pengguna, on_delete=models.CASCADE)
    date_created = models.DateField(auto_now=True)
    artikel = models.TextField()
    set_view = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def _str_(self):
        return self.artikel[:30]
    

    def __str__(self):
        return self.email  # Menampilkan email sebagai representasi objek
    
class Photo(models.Model):
    owner_name = models.CharField(max_length=100)
    image = models.ImageField(upload_to='uploads/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

